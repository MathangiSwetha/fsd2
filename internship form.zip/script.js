function Sub(){
    alert("registration succesfull Thank you!");
}